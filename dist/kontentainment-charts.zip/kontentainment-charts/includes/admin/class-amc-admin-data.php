<?php
/**
 * Admin data helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AMC_Admin_Data {
	/**
	 * Menu/page registry.
	 *
	 * @return array
	 */
	public static function pages() {
		return array(
			'dashboard'      => array( 'menu_slug' => 'kontentainment-charts', 'title' => 'Dashboard' ),
			'charts'         => array( 'menu_slug' => 'kontentainment-charts-charts', 'title' => 'Charts Management' ),
			'weekly-entries' => array( 'menu_slug' => 'kontentainment-charts-weeks', 'title' => 'Weekly Chart Entries' ),
			'tracks'         => array( 'menu_slug' => 'kontentainment-charts-tracks', 'title' => 'Tracks Management' ),
			'artists'        => array( 'menu_slug' => 'kontentainment-charts-artists', 'title' => 'Artists Management' ),
			'albums'         => array( 'menu_slug' => 'kontentainment-charts-albums', 'title' => 'Albums Management' ),
			'uploads'        => array( 'menu_slug' => 'kontentainment-charts-uploads', 'title' => 'Source Uploads' ),
			'cleaning'       => array( 'menu_slug' => 'kontentainment-charts-cleaning', 'title' => 'Matching and Cleaning' ),
			'scoring'        => array( 'menu_slug' => 'kontentainment-charts-scoring', 'title' => 'Scoring Rules' ),
			'publishing'     => array( 'menu_slug' => 'kontentainment-charts-publishing', 'title' => 'Publishing' ),
			'archives'       => array( 'menu_slug' => 'kontentainment-charts-archives', 'title' => 'Archive Management' ),
			'users'          => array( 'menu_slug' => 'kontentainment-charts-users', 'title' => 'Users and Roles' ),
			'settings'       => array( 'menu_slug' => 'kontentainment-charts-settings', 'title' => 'Settings' ),
		);
	}

	/**
	 * Lightweight wp-admin pages.
	 *
	 * @return array
	 */
	public static function wp_admin_pages() {
		return array(
			'overview'       => array( 'menu_slug' => 'kontentainment-charts', 'title' => 'Overview' ),
			'notifications'  => array( 'menu_slug' => 'kontentainment-charts-notifications', 'title' => 'Notifications' ),
			'settings'       => array( 'menu_slug' => 'kontentainment-charts-settings', 'title' => 'Settings' ),
			'tools'          => array( 'menu_slug' => 'kontentainment-charts-tools', 'title' => 'Tools' ),
			'logs'           => array( 'menu_slug' => 'kontentainment-charts-logs', 'title' => 'Logs' ),
			'permissions'    => array( 'menu_slug' => 'kontentainment-charts-permissions', 'title' => 'Permissions' ),
			'open-dashboard' => array( 'menu_slug' => 'kontentainment-charts-open-dashboard', 'title' => 'Open Dashboard' ),
		);
	}

	/**
	 * Full dashboard sections.
	 *
	 * @return array
	 */
	public static function dashboard_sections() {
		return array(
			'dashboard'      => array( 'title' => 'Dashboard', 'path' => '' ),
			'charts'         => array( 'title' => 'Charts', 'path' => 'charts' ),
			'weekly-entries' => array( 'title' => 'Weekly Entries', 'path' => 'weekly-entries' ),
			'tracks'         => array( 'title' => 'Tracks', 'path' => 'tracks' ),
			'artists'        => array( 'title' => 'Artists', 'path' => 'artists' ),
			'albums'         => array( 'title' => 'Albums', 'path' => 'albums' ),
			'uploads'        => array( 'title' => 'Source Uploads', 'path' => 'uploads' ),
			'cleaning'       => array( 'title' => 'Matching and Cleaning', 'path' => 'cleaning' ),
			'scoring'        => array( 'title' => 'Scoring Rules', 'path' => 'scoring' ),
			'publishing'     => array( 'title' => 'Publishing', 'path' => 'publishing' ),
			'jobs'           => array( 'title' => 'Jobs and Queue', 'path' => 'jobs' ),
			'archives'       => array( 'title' => 'Archive Management', 'path' => 'archives' ),
			'notifications'  => array( 'title' => 'Notifications', 'path' => 'notifications' ),
			'users'          => array( 'title' => 'Users and Roles', 'path' => 'users' ),
			'settings'       => array( 'title' => 'Settings', 'path' => 'settings' ),
		);
	}

	/**
	 * Resolve custom dashboard url.
	 *
	 * @param string $section Section key.
	 * @return string
	 */
	public static function custom_dashboard_url( $section = 'dashboard' ) {
		$sections = self::dashboard_sections();

		if ( empty( $sections[ $section ] ) || empty( $sections[ $section ]['path'] ) ) {
			return home_url( '/charts-dashboard/' );
		}

		return home_url( '/charts-dashboard/' . $sections[ $section ]['path'] . '/' );
	}

	/**
	 * Overview counts.
	 *
	 * @return array
	 */
	public static function overview_cards() {
		$counts = AMC_DB::dashboard_counts();

		return array(
			array( 'label' => 'Total Charts', 'value' => (string) $counts['charts'], 'delta' => self::count_label( 'chart_weeks', 'draft', 'draft weeks' ), 'tone' => 'gold' ),
			array( 'label' => 'Tracks In Library', 'value' => (string) $counts['tracks'], 'delta' => self::count_label( 'tracks', 'archived', 'archived' ), 'tone' => 'violet' ),
			array( 'label' => 'Artists In Library', 'value' => (string) $counts['artists'], 'delta' => self::count_label( 'artists', 'archived', 'archived' ), 'tone' => 'blue' ),
			array( 'label' => 'Albums In Library', 'value' => (string) $counts['albums'], 'delta' => self::count_label( 'albums', 'archived', 'archived' ), 'tone' => 'emerald' ),
		);
	}

	/**
	 * Production onboarding and readiness state.
	 *
	 * @return array
	 */
	public static function onboarding_status() {
		$charts_count     = AMC_DB::count_rows( 'charts', array( 'status' => 'active' ) );
		$uploads          = AMC_DB::get_rows( 'source_uploads', array( 'order_by' => 'id DESC' ) );
		$matching_queue   = AMC_DB::get_rows( 'matching_queue', array( 'order_by' => 'id DESC' ) );
		$weeks            = AMC_DB::get_chart_weeks();
		$scoring_rules    = AMC_Ingestion::get_scoring_rules();
		$published_weeks  = array();
		$draft_ready      = 0;
		$generated_weeks  = 0;
		$parsed_completed = false;
		$matched_done     = false;
		$first_upload     = ! empty( $uploads );
		$first_parsed     = false;

		foreach ( $uploads as $upload ) {
			if ( in_array( $upload['file_status'], array( 'parsed', 'matched', 'generated', 'published' ), true ) ) {
				$parsed_completed = true;
				$first_parsed     = true;
			}

			if ( in_array( $upload['file_status'], array( 'matched', 'generated', 'published' ), true ) ) {
				$matched_done = true;
			}
		}

		foreach ( $matching_queue as $item ) {
			if ( in_array( $item['status'], array( 'approved', 'rejected', 'overridden' ), true ) ) {
				$matched_done = true;
				break;
			}
		}

		foreach ( $weeks as $week ) {
			$entries = AMC_DB::get_chart_entries( (int) $week['id'] );

			if ( ! empty( $entries ) ) {
				++$generated_weeks;
			}

			if ( 'draft' === $week['status'] && ! empty( $entries ) ) {
				++$draft_ready;
			}

			if ( 'published' === $week['status'] ) {
				$published_weeks[] = $week;
			}
		}

		$has_scoring = false;

		if ( ! empty( $scoring_rules['weights'] ) ) {
			foreach ( $scoring_rules['weights'] as $rule ) {
				if ( '' !== (string) $rule['value'] ) {
					$has_scoring = true;
					break;
				}
			}
		}

		if ( ! $has_scoring && ! empty( $scoring_rules['methodology'] ) ) {
			foreach ( $scoring_rules['methodology'] as $value ) {
				if ( '' !== trim( (string) $value ) ) {
					$has_scoring = true;
					break;
				}
			}
		}

		$steps = array(
			array(
				'key'         => 'charts_created',
				'label'       => 'Create first chart',
				'description' => 'Set up at least one real chart category before the ingestion flow starts.',
				'complete'    => $charts_count > 0,
				'url'         => AMC_Admin_Data::custom_dashboard_url( 'charts' ),
				'action'      => 'Open Charts',
			),
			array(
				'key'         => 'scoring_configured',
				'label'       => 'Configure scoring rules',
				'description' => 'Save real source weights and methodology values for generation.',
				'complete'    => $has_scoring,
				'url'         => AMC_Admin_Data::custom_dashboard_url( 'scoring' ),
				'action'      => 'Open Scoring',
			),
			array(
				'key'         => 'first_upload_completed',
				'label'       => 'Upload first source file',
				'description' => 'Start the operational flow by uploading a real source sheet with chart metadata.',
				'complete'    => $first_upload,
				'url'         => AMC_Admin_Data::custom_dashboard_url( 'uploads' ),
				'action'      => 'Open Uploads',
			),
			array(
				'key'         => 'first_parsing_completed',
				'label'       => 'Review parsing',
				'description' => 'Confirm the parser accepts the file structure and normalizes rows cleanly.',
				'complete'    => $first_parsed,
				'url'         => AMC_Admin_Data::custom_dashboard_url( 'uploads' ),
				'action'      => 'Review Preview',
			),
			array(
				'key'         => 'first_matching_review_completed',
				'label'       => 'Review matching',
				'description' => 'Resolve review-needed entities before generating a live-ready draft week.',
				'complete'    => $matched_done,
				'url'         => AMC_Admin_Data::custom_dashboard_url( 'cleaning' ),
				'action'      => 'Open Matching',
			),
			array(
				'key'         => 'first_chart_generated',
				'label'       => 'Generate first chart week',
				'description' => 'Build a draft chart week from approved upload rows and scoring rules.',
				'complete'    => $generated_weeks > 0,
				'url'         => AMC_Admin_Data::custom_dashboard_url( 'weekly-entries' ),
				'action'      => 'Open Weekly Entries',
			),
			array(
				'key'         => 'first_chart_published',
				'label'       => 'Publish first live chart',
				'description' => 'Push the first approved chart week live so the public site starts serving real data.',
				'complete'    => ! empty( $published_weeks ),
				'url'         => AMC_Admin_Data::custom_dashboard_url( 'publishing' ),
				'action'      => 'Open Publishing',
			),
		);

		$completed = count(
			array_filter(
				$steps,
				function ( $step ) {
					return ! empty( $step['complete'] );
				}
			)
		);

		return array(
			'is_ready'             => $completed === count( $steps ),
			'completed_steps'      => $completed,
			'total_steps'          => count( $steps ),
			'steps'                => $steps,
			'charts_count'         => $charts_count,
			'first_upload'         => $first_upload,
			'parsed_completed'     => $parsed_completed,
			'matching_completed'   => $matched_done,
			'generated_weeks'      => $generated_weeks,
			'draft_ready'          => $draft_ready,
			'published_weeks'      => count( $published_weeks ),
			'has_scoring'          => $has_scoring,
		);
	}

	/**
	 * Operational summary for live dashboard use.
	 *
	 * @return array
	 */
	public static function operational_summary() {
		$uploads            = self::uploads();
		$matching_candidates= self::matching_candidates();
		$weeks              = AMC_DB::get_chart_weeks();
		$jobs               = AMC_DB::jobs_summary();
		$job_metrics        = AMC_DB::job_metrics();
		$ready_to_generate  = 0;
		$draft_ready        = 0;
		$live_weeks         = array();
		$ready_to_create    = 0;

		foreach ( $uploads as $upload ) {
			if ( in_array( $upload['raw_status'], array( 'matched', 'generated', 'published' ), true ) && empty( $upload['is_dry_run'] ) ) {
				++$ready_to_generate;
			}

			if ( ! empty( $upload['diagnostic_summary']['auto_created_rows'] ) ) {
				$ready_to_create += (int) $upload['diagnostic_summary']['auto_created_rows'];
			}
		}

		foreach ( $weeks as $week ) {
			$chart = AMC_DB::get_row( 'charts', (int) $week['chart_id'] );
			$entry_count = count( AMC_DB::get_chart_entries( (int) $week['id'] ) );

			if ( 'draft' === $week['status'] && $entry_count > 0 ) {
				++$draft_ready;
			}

			if ( 'published' === $week['status'] ) {
				$live_weeks[] = array(
					'chart'   => $chart ? $chart['name'] : 'Unknown chart',
					'country' => ! empty( $week['country'] ) ? $week['country'] : 'Global',
					'week'    => $week['week_date'],
				);
			}
		}

		$pending_review = count(
			array_filter(
				$matching_candidates,
				function ( $row ) {
					return in_array( $row['raw_status'], array( 'pending', 'review_needed' ), true );
				}
			)
		);

		return array(
			'latest_uploads'      => array_slice( $uploads, 0, 5 ),
			'pending_review'      => $pending_review,
			'ready_to_create'     => $ready_to_create,
			'charts_ready'        => $ready_to_generate,
			'draft_ready'         => $draft_ready,
			'live_weeks'          => array_slice( $live_weeks, 0, 6 ),
			'jobs'                => $jobs,
			'job_average_duration'=> $job_metrics['average_duration'],
		);
	}

	/**
	 * Operator notifications.
	 *
	 * @return array
	 */
	public static function notifications() {
		$notifications = self::notification_center();

		return array_values(
			array_slice(
				array_filter(
					$notifications,
					function ( $notification ) {
						return 'Dismissed' !== $notification['status'];
					}
				),
				0,
				6
			)
		);
	}

	/**
	 * Full notification center data with filters.
	 *
	 * @param array $filters Filters.
	 * @return array
	 */
	public static function notification_center( $filters = array() ) {
		$defaults      = array(
			'severity' => '',
			'status'   => '',
			'date'     => '',
		);
		$filters       = wp_parse_args( $filters, $defaults );
		$notifications = AMC_Ingestion::notifications();
		$notifications = is_array( $notifications ) ? array_reverse( $notifications ) : array();

		$rows = array_values(
			array_filter(
				$notifications,
				function ( $notification ) use ( $filters ) {
					if ( ! empty( $filters['severity'] ) && ( empty( $notification['type'] ) || $notification['type'] !== $filters['severity'] ) ) {
						return false;
					}

					if ( ! empty( $filters['status'] ) ) {
						if ( 'unread' === $filters['status'] && ! empty( $notification['is_read'] ) ) {
							return false;
						}

						if ( 'read' === $filters['status'] && empty( $notification['is_read'] ) ) {
							return false;
						}

						if ( 'dismissed' === $filters['status'] && empty( $notification['is_dismissed'] ) ) {
							return false;
						}
					}

					if ( ! empty( $filters['date'] ) && ( empty( $notification['created_at'] ) || 0 !== strpos( $notification['created_at'], $filters['date'] ) ) ) {
						return false;
					}

					return true;
				}
			)
		);

		$rows = array_map(
			function ( $notification ) {
				$context = ! empty( $notification['context'] ) && is_array( $notification['context'] ) ? $notification['context'] : array();
				$group_count = ! empty( $notification['occurrence_count'] ) ? (int) $notification['occurrence_count'] : 1;
				return array(
					'id'         => ! empty( $notification['id'] ) ? $notification['id'] : '',
					'severity'   => ! empty( $notification['type'] ) ? ucfirst( $notification['type'] ) : 'Info',
					'message'    => ! empty( $notification['message'] ) ? $notification['message'] : '',
					'status'     => ! empty( $notification['is_dismissed'] ) ? 'Dismissed' : ( ! empty( $notification['is_read'] ) ? 'Read' : 'Unread' ),
					'created_at' => ! empty( $notification['created_at'] ) ? $notification['created_at'] : '',
					'last_seen'  => ! empty( $notification['last_seen_at'] ) ? $notification['last_seen_at'] : ( ! empty( $notification['created_at'] ) ? $notification['created_at'] : '' ),
					'count'      => $group_count,
					'context'    => $context,
				);
			},
			$rows
		);

		usort(
			$rows,
			function ( $a, $b ) {
				return strcmp( $b['last_seen'], $a['last_seen'] );
			}
		);

		return $rows;
	}

	/**
	 * Public page quick links.
	 *
	 * @return array
	 */
	public static function public_page_links() {
		return array(
			array( 'label' => 'Home', 'url' => AMC_Data::route_url() ),
			array( 'label' => 'Charts Index', 'url' => AMC_Data::route_url( 'charts' ) ),
			array( 'label' => 'Top Artists', 'url' => AMC_Data::route_url( 'charts/top-artists' ) ),
			array( 'label' => 'Top Tracks', 'url' => AMC_Data::route_url( 'charts/top-tracks' ) ),
			array( 'label' => 'Top Albums', 'url' => AMC_Data::route_url( 'charts/top-albums' ) ),
			array( 'label' => 'Hot 100 Tracks', 'url' => AMC_Data::route_url( 'charts/hot-100-tracks' ) ),
			array( 'label' => 'Hot 100 Artists', 'url' => AMC_Data::route_url( 'charts/hot-100-artists' ) ),
			array( 'label' => 'All Artists', 'url' => AMC_Data::route_url( 'artists' ) ),
			array( 'label' => 'All Tracks', 'url' => AMC_Data::route_url( 'tracks' ) ),
			array( 'label' => 'About Charts', 'url' => AMC_Data::route_url( 'about' ) ),
		);
	}

	/**
	 * Notification filters from request.
	 *
	 * @return array
	 */
	public static function notification_filters_from_request() {
		return array(
			'severity' => isset( $_GET['notice_severity'] ) ? sanitize_key( wp_unslash( $_GET['notice_severity'] ) ) : '',
			'status'   => isset( $_GET['notice_status'] ) ? sanitize_key( wp_unslash( $_GET['notice_status'] ) ) : '',
			'date'     => isset( $_GET['notice_date'] ) ? sanitize_text_field( wp_unslash( $_GET['notice_date'] ) ) : '',
		);
	}

	/**
	 * Queue jobs for dashboard and admin views.
	 *
	 * @param array $filters Optional filters.
	 * @return array
	 */
	public static function jobs( $filters = array() ) {
		$rows = AMC_DB::get_jobs( $filters );

		return array_map(
			function ( $row ) {
				$duration = '';
				if ( ! empty( $row['started_at'] ) && ! empty( $row['completed_at'] ) ) {
					$duration = max( 0, strtotime( $row['completed_at'] ) - strtotime( $row['started_at'] ) ) . 's';
				}

				$related = array();
				if ( ! empty( $row['reference_type'] ) ) {
					$related[] = ucfirst( $row['reference_type'] ) . ' #' . (int) $row['reference_id'];
				}
				if ( ! empty( $row['chart_name'] ) ) {
					$related[] = $row['chart_name'];
				}
				if ( ! empty( $row['country'] ) ) {
					$related[] = $row['country'];
				}
				if ( ! empty( $row['week_date'] ) ) {
					$related[] = $row['week_date'];
				}

				return array(
					'id'            => (int) $row['id'],
					'job_type'      => ucwords( str_replace( '_', ' ', $row['job_type'] ) ),
					'raw_job_type'  => $row['job_type'],
					'related'       => ! empty( $related ) ? implode( ' / ', $related ) : 'General operation',
					'state'         => ucfirst( $row['status'] ),
					'raw_state'     => $row['status'],
					'created_time'  => $row['created_at'],
					'started_time'  => ! empty( $row['started_at'] ) ? $row['started_at'] : 'Not started',
					'finished_time' => ! empty( $row['completed_at'] ) ? $row['completed_at'] : 'Not finished',
					'duration'      => $duration ? $duration : 'Pending',
					'attempts'      => (int) $row['attempts'],
					'max_attempts'  => ! empty( $row['max_attempts'] ) ? (int) $row['max_attempts'] : 0,
					'next_retry_at' => ! empty( $row['next_retry_at'] ) ? $row['next_retry_at'] : '',
					'last_error_step' => ! empty( $row['last_error_step'] ) ? ucwords( str_replace( '_', ' ', $row['last_error_step'] ) ) : '',
					'failure_reason'=> ! empty( $row['error_message'] ) ? $row['error_message'] : '',
					'trigger_mode'  => ! empty( $row['trigger_mode'] ) ? ucfirst( $row['trigger_mode'] ) : 'Manual',
					'chart_name'    => ! empty( $row['chart_name'] ) ? $row['chart_name'] : '',
					'country'       => ! empty( $row['country'] ) ? $row['country'] : '',
					'week_date'     => ! empty( $row['week_date'] ) ? $row['week_date'] : '',
					'reference_id'  => (int) $row['reference_id'],
					'reference_type'=> ! empty( $row['reference_type'] ) ? $row['reference_type'] : '',
				);
			},
			$rows
		);
	}

	/**
	 * Job queue filters from request.
	 *
	 * @return array
	 */
	public static function job_filters_from_request() {
		return array(
			'status'   => isset( $_GET['job_status'] ) ? sanitize_key( wp_unslash( $_GET['job_status'] ) ) : '',
			'job_type' => isset( $_GET['job_type'] ) ? sanitize_key( wp_unslash( $_GET['job_type'] ) ) : '',
			'chart_id' => isset( $_GET['job_chart_id'] ) ? absint( wp_unslash( $_GET['job_chart_id'] ) ) : 0,
			'country'  => isset( $_GET['job_country'] ) ? sanitize_text_field( wp_unslash( $_GET['job_country'] ) ) : '',
			'week_date'=> isset( $_GET['job_week_date'] ) ? sanitize_text_field( wp_unslash( $_GET['job_week_date'] ) ) : '',
		);
	}

	/**
	 * Dashboard job observability snapshot.
	 *
	 * @return array
	 */
	public static function job_observability() {
		$metrics = AMC_DB::job_metrics();
		return array(
			'summary'         => AMC_DB::jobs_summary(),
			'average_duration'=> $metrics['average_duration'],
			'recent_failures' => array_slice( self::jobs( array( 'status' => 'failed', 'limit' => 5 ) ), 0, 5 ),
			'by_type'         => ! empty( $metrics['by_type'] ) ? $metrics['by_type'] : array(),
			'backlog'         => ! empty( $metrics['backlog'] ) ? $metrics['backlog'] : array(),
		);
	}

	/**
	 * Upload guidance copy.
	 *
	 * @return array
	 */
	public static function upload_guidance() {
		return array(
			array(
				'title' => 'YouTube Top Artists',
				'copy'  => 'Choose artist chart type, select the target chart manually, then upload a file containing artist or channel name, rank, and optional growth or views columns.',
			),
			array(
				'title' => 'YouTube Top Songs',
				'copy'  => 'Use the track chart type with title, artist, rank, and views or plays columns. Include the exact week/date and country before upload.',
			),
			array(
				'title' => 'Spotify Weekly',
				'copy'  => 'Use the real target chart, set the country manually, and upload weekly CSV data with title, artist, streams or plays, and optional previous rank fields. The column named "source" is ignored automatically.',
			),
			array(
				'title' => 'Shazam Chart',
				'copy'  => 'Use track chart type and provide title, artist, rank, and chart metric columns. Confirm the chart week/date before processing.',
			),
		);
	}

	/**
	 * First-publish review summary.
	 *
	 * @param int $week_id Optional week id.
	 * @return array
	 */
	public static function first_publish_summary( $week_id = 0 ) {
		$week = $week_id ? AMC_DB::get_row( 'chart_weeks', $week_id ) : null;

		if ( ! $week ) {
			$weeks = AMC_DB::get_chart_weeks();
			$week  = ! empty( $weeks[0] ) ? $weeks[0] : null;
		}

		if ( ! $week ) {
			return array(
				'available' => false,
				'safety'    => array(),
				'summary'   => array(),
			);
		}

		$chart           = AMC_DB::get_row( 'charts', (int) $week['chart_id'] );
		$entries         = AMC_DB::get_chart_entries( (int) $week['id'] );
		$uploads         = self::uploads();
		$related_uploads = array_filter(
			$uploads,
			function ( $upload ) use ( $week ) {
				return (int) $upload['target_chart_id'] === (int) $week['chart_id']
					&& (string) $upload['country'] === (string) $week['country']
					&& (string) $upload['chart_date'] === (string) $week['week_date'];
			}
		);
		$valid_rows      = 0;
		$matched_rows    = 0;
		$rejected_rows   = 0;
		$review_rows     = 0;

		foreach ( $related_uploads as $upload ) {
			$diag = ! empty( $upload['diagnostic_summary'] ) && is_array( $upload['diagnostic_summary'] ) ? $upload['diagnostic_summary'] : array();
			$valid_rows   += ! empty( $diag['valid_rows'] ) ? (int) $diag['valid_rows'] : 0;
			$matched_rows += ! empty( $diag['matched_rows'] ) ? (int) $diag['matched_rows'] : 0;
			$rejected_rows+= ! empty( $diag['rejected_rows'] ) ? (int) $diag['rejected_rows'] : 0;
			$review_rows  += ! empty( $diag['review_needed_rows'] ) ? (int) $diag['review_needed_rows'] : ( ! empty( $diag['review_needed'] ) ? (int) $diag['review_needed'] : 0 );
		}

		$safety = array(
			array(
				'label' => 'Has generated entries',
				'state' => ! empty( $entries ),
				'copy'  => ! empty( $entries ) ? 'This week contains generated ranking rows.' : 'Generate this chart week before publishing.',
			),
			array(
				'label' => 'Matching review queue',
				'state' => 0 === $review_rows,
				'copy'  => 0 === $review_rows ? 'No review-needed rows remain for this chart week.' : $review_rows . ' rows still need manual review.',
			),
			array(
				'label' => 'Live conflict check',
				'state' => 'published' !== $week['status'],
				'copy'  => 'published' !== $week['status'] ? 'This week is not already marked live.' : 'This week is already published.',
			),
		);

		return array(
			'available' => true,
			'summary'   => array(
				'Chart'                => $chart ? $chart['name'] : 'Unknown chart',
				'Country'              => ! empty( $week['country'] ) ? $week['country'] : 'Global',
				'Week / date'          => $week['week_date'],
				'Valid rows'           => $valid_rows,
				'Matched entities'     => $matched_rows,
				'Rejected rows'        => $rejected_rows,
				'Review-needed rows'   => $review_rows,
				'Generated entries'    => count( $entries ),
				'Generation summary'   => ! empty( $week['comparison_summary'] ) ? $week['comparison_summary'] : 'Draft week generated and ready for final review.',
			),
			'safety'    => $safety,
		);
	}

	/**
	 * Recent uploads.
	 *
	 * @return array
	 */
	public static function recent_uploads() {
		$uploads = AMC_DB::get_rows( 'source_uploads', array( 'order_by' => 'id DESC', 'limit' => 4 ) );

		return array_map(
			function ( $row ) {
				$user = ! empty( $row['uploader_id'] ) ? get_user_by( 'id', (int) $row['uploader_id'] ) : null;
				$chart = ! empty( $row['target_chart_id'] ) ? AMC_DB::get_row( 'charts', (int) $row['target_chart_id'] ) : null;

				return array(
					'source'     => AMC_Ingestion::platform_label( ! empty( $row['source_platform'] ) ? $row['source_platform'] : $row['source_name'] ),
					'chart_week' => trim( $row['country'] . ' / ' . $row['chart_week'] . ( $chart ? ' / ' . $chart['name'] : '' ), ' /' ),
					'status'     => ucfirst( $row['file_status'] ),
					'rows'       => (int) $row['row_count'],
					'uploader'   => $user ? $user->display_name : 'System',
				);
			},
			$uploads
		);
	}

	/**
	 * Alerts.
	 *
	 * @return array
	 */
	public static function alerts() {
		global $wpdb;

		$tracks_table  = AMC_DB::table( 'tracks' );
		$artists_table = AMC_DB::table( 'artists' );
		$albums_table  = AMC_DB::table( 'albums' );
		$dupes         = (int) $wpdb->get_var( "SELECT COUNT(*) FROM (SELECT slug FROM {$tracks_table} GROUP BY slug HAVING COUNT(*) > 1) duplicate_tracks" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$missing       = AMC_DB::count_rows( 'tracks', array( 'cover_image' => '' ) ) + AMC_DB::count_rows( 'artists', array( 'image' => '' ) ) + AMC_DB::count_rows( 'albums', array( 'cover_image' => '' ) );
		$draft_weeks   = AMC_DB::count_rows( 'chart_weeks', array( 'status' => 'draft' ) );

		return array(
			array( 'title' => 'Duplicate track candidates', 'body' => $dupes ? $dupes . ' duplicate slugs need manual review.' : 'No duplicate track slugs are currently detected.', 'tone' => 'warning' ),
			array( 'title' => 'Missing artwork', 'body' => $missing ? $missing . ' artist, album, or track records still need artwork.' : 'No missing artwork issues are currently detected.', 'tone' => 'danger' ),
			array( 'title' => 'Draft chart weeks', 'body' => $draft_weeks ? $draft_weeks . ' chart weeks are still waiting for publication flow.' : 'No pending draft weeks right now.', 'tone' => 'info' ),
		);
	}

	/**
	 * Week status.
	 *
	 * @return array
	 */
	public static function chart_week_status() {
		return array(
			array( 'label' => 'Published Weeks', 'value' => AMC_DB::count_rows( 'chart_weeks', array( 'status' => 'published' ) ) ),
			array( 'label' => 'Draft Weeks', 'value' => AMC_DB::count_rows( 'chart_weeks', array( 'status' => 'draft' ) ) ),
			array( 'label' => 'Archived Weeks', 'value' => AMC_DB::count_rows( 'chart_weeks', array( 'status' => 'archived' ) ) ),
		);
	}

	/**
	 * Chart categories.
	 *
	 * @return array
	 */
	public static function chart_categories() {
		$rows = AMC_DB::get_rows( 'charts', array( 'order_by' => 'display_order ASC, id ASC' ) );

		return array_map(
			function ( $row ) {
				return array(
					'id'            => (int) $row['id'],
					'name'          => $row['name'],
					'slug'          => $row['slug'],
					'type'          => ucfirst( $row['type'] ) . 's',
					'display_order' => (int) $row['display_order'],
					'active'        => 'active' === $row['status'] ? 'Active' : 'Hidden',
					'featured'      => ! empty( $row['is_featured_home'] ) ? 'Yes' : 'No',
					'archive'       => ! empty( $row['archive_enabled'] ) ? 'Enabled' : 'Disabled',
					'accent'        => $row['accent'],
					'description'   => $row['description'],
					'kicker'        => $row['kicker'],
					'status'        => $row['status'],
				);
			},
			$rows
		);
	}

	/**
	 * Weekly entries sample.
	 *
	 * @return array
	 */
	public static function weekly_entries() {
		$weeks = AMC_DB::get_chart_weeks();
		$week  = ! empty( $weeks[0] ) ? $weeks[0] : null;

		if ( ! $week ) {
			return array();
		}

		return self::entries_for_week( (int) $week['id'] );
	}

	/**
	 * Tracks sample.
	 *
	 * @return array
	 */
	public static function tracks() {
		$filters = self::track_filters_from_request();
		$rows    = AMC_DB::get_rows(
			'tracks',
			array(
				'where'          => array(
					'status'    => $filters['status'],
					'artist_id' => $filters['artist_id'],
					'album_id'  => $filters['album_id'],
				),
				'search'         => $filters['search'],
				'search_columns' => array( 'title', 'isrc', 'aliases', 'genre' ),
				'order_by'       => 'title ASC',
			)
		);

		return array_map(
			function ( $row ) {
				$artist = ! empty( $row['artist_id'] ) ? AMC_DB::get_row( 'artists', (int) $row['artist_id'] ) : null;
				$album  = ! empty( $row['album_id'] ) ? AMC_DB::get_row( 'albums', (int) $row['album_id'] ) : null;

				return array(
					'id'           => (int) $row['id'],
					'title'        => $row['title'],
					'slug'         => $row['slug'],
					'artist'       => $artist ? $artist['name'] : 'Unknown',
					'album'        => $album ? $album['title'] : 'Standalone',
					'isrc'         => $row['isrc'],
					'aliases'      => $row['aliases'],
					'release_date' => $row['release_date'],
					'genre'        => $row['genre'],
					'status'       => ucfirst( $row['status'] ),
					'raw_status'   => $row['status'],
					'artist_id'    => (int) $row['artist_id'],
					'album_id'     => (int) $row['album_id'],
					'duration'     => $row['duration'],
					'description'  => $row['description'],
					'gradient'     => $row['gradient'],
				);
			},
			$rows
		);
	}

	/**
	 * Artists sample.
	 *
	 * @return array
	 */
	public static function artists() {
		$filters = self::artist_filters_from_request();
		$rows    = AMC_DB::get_rows(
			'artists',
			array(
				'where'          => array(
					'status'  => $filters['status'],
					'country' => $filters['country'],
				),
				'search'         => $filters['search'],
				'search_columns' => array( 'name', 'slug', 'aliases', 'genre', 'bio' ),
				'order_by'       => 'name ASC',
			)
		);

		return array_map(
			function ( $row ) {
				return array(
					'id'             => (int) $row['id'],
					'name'           => $row['name'],
					'slug'           => $row['slug'],
					'country'        => $row['country'],
					'genre'          => $row['genre'],
					'socials'        => $row['social_links'],
					'related_tracks' => AMC_DB::count_rows( 'tracks', array( 'artist_id' => (int) $row['id'] ) ),
					'related_albums' => AMC_DB::count_rows( 'albums', array( 'artist_id' => (int) $row['id'] ) ),
					'status'         => ucfirst( $row['status'] ),
					'raw_status'     => $row['status'],
					'bio'            => $row['bio'],
					'monthly'        => $row['monthly_listeners'],
					'streak'         => $row['chart_streak'],
					'gradient'       => $row['gradient'],
				);
			},
			$rows
		);
	}

	/**
	 * Albums sample.
	 *
	 * @return array
	 */
	public static function albums() {
		$filters = self::album_filters_from_request();
		$rows    = AMC_DB::get_rows(
			'albums',
			array(
				'where'          => array(
					'status'    => $filters['status'],
					'artist_id' => $filters['artist_id'],
				),
				'search'         => $filters['search'],
				'search_columns' => array( 'title', 'slug', 'genre', 'label' ),
				'order_by'       => 'title ASC',
			)
		);

		return array_map(
			function ( $row ) {
				$artist = ! empty( $row['artist_id'] ) ? AMC_DB::get_row( 'artists', (int) $row['artist_id'] ) : null;

				return array(
					'id'             => (int) $row['id'],
					'title'          => $row['title'],
					'slug'           => $row['slug'],
					'artist'         => $artist ? $artist['name'] : 'Unknown',
					'release_date'   => $row['release_date'],
					'genre'          => $row['genre'],
					'label'          => $row['label'],
					'related_tracks' => AMC_DB::count_rows( 'tracks', array( 'album_id' => (int) $row['id'] ) ),
					'status'         => ucfirst( $row['status'] ),
					'raw_status'     => $row['status'],
					'artist_id'      => (int) $row['artist_id'],
					'gradient'       => $row['gradient'],
				);
			},
			$rows
		);
	}

	public static function track_filters_from_request() {
		return array(
			'status'    => isset( $_GET['track_status'] ) ? sanitize_key( wp_unslash( $_GET['track_status'] ) ) : '',
			'artist_id' => isset( $_GET['track_artist_id'] ) ? absint( wp_unslash( $_GET['track_artist_id'] ) ) : 0,
			'album_id'  => isset( $_GET['track_album_id'] ) ? absint( wp_unslash( $_GET['track_album_id'] ) ) : 0,
			'search'    => isset( $_GET['track_search'] ) ? sanitize_text_field( wp_unslash( $_GET['track_search'] ) ) : '',
		);
	}

	public static function artist_filters_from_request() {
		return array(
			'status'  => isset( $_GET['artist_status'] ) ? sanitize_key( wp_unslash( $_GET['artist_status'] ) ) : '',
			'country' => isset( $_GET['artist_country'] ) ? sanitize_text_field( wp_unslash( $_GET['artist_country'] ) ) : '',
			'search'  => isset( $_GET['artist_search'] ) ? sanitize_text_field( wp_unslash( $_GET['artist_search'] ) ) : '',
		);
	}

	public static function album_filters_from_request() {
		return array(
			'status'    => isset( $_GET['album_status'] ) ? sanitize_key( wp_unslash( $_GET['album_status'] ) ) : '',
			'artist_id' => isset( $_GET['album_artist_id'] ) ? absint( wp_unslash( $_GET['album_artist_id'] ) ) : 0,
			'search'    => isset( $_GET['album_search'] ) ? sanitize_text_field( wp_unslash( $_GET['album_search'] ) ) : '',
		);
	}

	/**
	 * Upload sources.
	 *
	 * @return array
	 */
	public static function uploads() {
		$rows = AMC_DB::get_rows( 'source_uploads', array( 'order_by' => 'id DESC' ) );

		return array_map(
			function ( $row ) {
				$user = ! empty( $row['uploader_id'] ) ? get_user_by( 'id', (int) $row['uploader_id'] ) : null;
				$chart = ! empty( $row['target_chart_id'] ) ? AMC_DB::get_row( 'charts', (int) $row['target_chart_id'] ) : null;

				return array(
					'id'          => (int) $row['id'],
					'source'      => AMC_Ingestion::platform_label( ! empty( $row['source_platform'] ) ? $row['source_platform'] : $row['source_name'] ),
					'source_platform' => ! empty( $row['source_platform'] ) ? $row['source_platform'] : sanitize_title( $row['source_name'] ),
					'upload_date' => $row['created_at'],
					'week'        => $row['chart_week'],
					'country'     => ! empty( $row['country'] ) ? $row['country'] : 'Global',
					'chart_date'  => ! empty( $row['chart_date'] ) ? $row['chart_date'] : $row['chart_week'],
					'chart'       => $chart ? $chart['name'] : 'Unknown chart',
					'chart_type'  => ucfirst( $row['chart_type'] ),
					'target_chart_id' => (int) $row['target_chart_id'],
					'status'      => ucfirst( $row['file_status'] ),
					'raw_status'  => $row['file_status'],
					'generated_week_id' => (int) $row['generated_week_id'],
					'row_count'   => (int) $row['row_count'],
					'preview'     => $row['error_message'] ? $row['error_message'] : $row['preview_text'],
					'diagnostic_summary' => ! empty( $row['diagnostic_summary'] ) ? json_decode( $row['diagnostic_summary'], true ) : array(),
					'is_duplicate'=> ! empty( $row['is_duplicate'] ),
					'duplicate_of_upload_id' => (int) $row['duplicate_of_upload_id'],
					'is_dry_run'  => ! empty( $row['is_dry_run'] ),
					'uploader'    => $user ? $user->display_name : 'System',
					'file_name'   => $row['file_name'],
					'file_url'    => $row['file_url'],
					'error'       => $row['error_message'],
				);
			},
			$rows
		);
	}

	/**
	 * Matching data.
	 *
	 * @return array
	 */
	public static function matching_candidates() {
		$rows = AMC_DB::get_rows( 'matching_queue', array( 'order_by' => 'id DESC' ) );

		return array_map(
			function ( $row ) {
				$source_row = AMC_DB::get_row( 'source_rows', (int) $row['source_row_id'] );
				$candidate  = trim( ( ! empty( $source_row['track_title'] ) ? $source_row['track_title'] : ( ! empty( $source_row['artist_name'] ) ? $source_row['artist_name'] : 'Unknown candidate' ) ) . ' / ' . ( ! empty( $source_row['artist_names'] ) ? $source_row['artist_names'] : '' ), ' /' );
				$upload     = AMC_DB::get_row( 'source_uploads', (int) $row['upload_id'] );
				$chart      = ( $upload && ! empty( $upload['target_chart_id'] ) ) ? AMC_DB::get_row( 'charts', (int) $upload['target_chart_id'] ) : null;
				$row_type   = ! empty( $row['row_type'] ) ? $row['row_type'] : 'review needed';
				$resolution = ! empty( $source_row['match_resolution'] ) ? $source_row['match_resolution'] : '';
				$auto_type  = ! empty( $source_row['auto_created_entity_type'] ) ? ucfirst( $source_row['auto_created_entity_type'] ) : '';
				$confidence = '';

				if ( 'auto_created' === $row['status'] ) {
					$confidence = 'Created automatically';
				} elseif ( ! empty( $row['confidence_label'] ) ) {
					$confidence_value = (float) $row['confidence'];
					$confidence = $confidence_value > 0 ? rtrim( rtrim( number_format( $confidence_value, 0, '.', '' ), '0' ), '.' ) . '% / ' . ucwords( str_replace( '-', ' ', $row['confidence_label'] ) ) : ucwords( str_replace( '-', ' ', $row['confidence_label'] ) );
				} elseif ( (float) $row['confidence'] > 0 ) {
					$confidence = rtrim( rtrim( number_format( (float) $row['confidence'], 0, '.', '' ), '0' ), '.' ) . '%';
				} else {
					$confidence = 'Needs review';
				}

				$recommended = 'Approve suggested match';
				if ( 'auto_created' === $resolution ) {
					$recommended = 'Continue to generation';
				} elseif ( 'matched_existing' === $resolution ) {
					$recommended = 'Continue to generation';
				} elseif ( 'review_needed' === $row['status'] && (int) $row['candidate_entity_id'] > 0 ) {
					$recommended = 'Review suggested match';
				} elseif ( 'review_needed' === $row['status'] ) {
					$recommended = 'Create or override carefully';
				} elseif ( 'rejected' === $row['status'] ) {
					$recommended = 'No further action';
				}

				return array(
					'id'         => (int) $row['id'],
					'candidate'  => $candidate,
					'type'       => ucfirst( $row['entity_type'] ),
					'row_type'   => ucwords( $row_type ),
					'confidence' => $confidence,
					'basis'      => ! empty( $row['match_basis'] ) ? $row['match_basis'] : 'No reliable match signal was recorded',
					'sources'    => $upload ? trim( AMC_Ingestion::platform_label( ! empty( $upload['source_platform'] ) ? $upload['source_platform'] : $upload['source_name'] ) . ' / ' . $upload['country'] . ' / ' . $upload['chart_week'] . ( $chart ? ' / ' . $chart['name'] : '' ), ' /' ) : 'Unknown source',
					'status'     => ucwords( str_replace( '_', ' ', $row['status'] ) ),
					'raw_status' => $row['status'],
					'action_hint'=> ! empty( $row['action_hint'] ) ? $row['action_hint'] : 'Review this row before generation.',
					'recommended_action' => $recommended,
					'resolution' => $resolution,
					'create_mode'=> 'auto_created' === $resolution ? trim( $auto_type . ' created automatically' ) : ( 'manual_override' === $resolution ? 'Manually overridden' : ( 'matched_existing' === $resolution ? 'Matched to existing entity' : ( (int) $row['candidate_entity_id'] > 0 ? 'Possible existing match' : 'Possible new entity' ) ) ),
					'candidate_link' => (int) $row['candidate_entity_id'] > 0 ? admin_url( 'admin.php?page=kontentainment-charts-' . $row['entity_type'] . 's&' . $row['entity_type'] . '_id=' . (int) $row['candidate_entity_id'] ) : '',
					'queue'      => $row,
					'source_row' => $source_row, // Added for Phase 3 hardening
				);
			},
			$rows
		);
	}

	/**
	 * Scoring data.
	 *
	 * @return array
	 */
	public static function scoring() {
		return AMC_Ingestion::get_scoring_rules();
	}

	/**
	 * Publishing preview data.
	 *
	 * @return array
	 */
	public static function publishing_preview() {
		$weeks = AMC_DB::get_chart_weeks();
		$week  = ! empty( $weeks[0] ) ? $weeks[0] : null;

		if ( ! $week ) {
			return array(
				'current_week' => 'No chart week available',
				'comparison'   => array(),
				'actions'      => array( 'Create Draft Week' ),
			);
		}

		$entries  = AMC_DB::get_chart_entries( (int) $week['id'] );
		$chart    = AMC_DB::get_row( 'charts', (int) $week['chart_id'] );
		$dropped  = ! empty( $week['dropped_out_json'] ) ? json_decode( $week['dropped_out_json'], true ) : array();
		$new      = 0;
		$reentry  = 0;
		$jump     = 0;
		$dropout  = is_array( $dropped ) ? count( $dropped ) : 0;

		foreach ( $entries as $entry ) {
			if ( 'new' === $entry['movement'] ) {
				++$new;
			}

			if ( 're-entry' === $entry['movement'] ) {
				++$reentry;
			}

			if ( absint( $entry['previous_rank'] ) > 0 ) {
				$jump = max( $jump, absint( $entry['previous_rank'] ) - absint( $entry['current_rank'] ) );
			}
		}

		return array(
			'current_week'   => trim( ( $chart ? $chart['name'] : 'Chart' ) . ' / ' . $week['country'] . ' / Week of ' . wp_date( 'F j, Y', strtotime( $week['week_date'] ) ), ' /' ),
			'comparison'     => array(
				array( 'metric' => 'New entries', 'value' => (string) $new ),
				array( 'metric' => 'Re-entries', 'value' => (string) $reentry ),
				array( 'metric' => 'Biggest jump', 'value' => $jump ? '+' . $jump . ' positions' : 'No upward movement' ),
				array( 'metric' => 'Dropped out', 'value' => (string) $dropout ),
				array( 'metric' => 'Status', 'value' => ucfirst( $week['status'] ) ),
			),
			'actions'        => array( 'Generate Draft', 'Preview Draft', 'Compare With Previous Week', 'Publish Week', 'Unpublish Week', 'Feature On Homepage' ),
			'dropped_out'    => is_array( $dropped ) ? $dropped : array(),
		);
	}

	/**
	 * Archive sample.
	 *
	 * @return array
	 */
	public static function archives() {
		$weeks  = AMC_DB::get_chart_weeks();
		$charts = self::chart_lookup();

		return array_map(
			function ( $row ) use ( $charts ) {
				return array(
					'id'      => (int) $row['id'],
					'week'    => $row['week_date'],
					'chart'   => ! empty( $charts[ $row['chart_id'] ] ) ? $charts[ $row['chart_id'] ]['name'] : 'Unknown chart',
					'charts'  => 1,
					'status'  => ucfirst( $row['status'] ),
					'notes'   => $row['notes'],
					'actions' => 'archived' === $row['status'] ? 'Restore' : 'Archive',
				);
			},
			$weeks
		);
	}

	/**
	 * User roles.
	 *
	 * @return array
	 */
	public static function users() {
		global $wp_roles;

		$map = array(
			'administrator'   => 'Full control',
			'editor'          => 'Edit charts, library, weeks, publish',
			'amc_data_manager'=> 'Charts, library, weeks',
			'amc_viewer'      => 'Read-only dashboard visibility',
		);

		$rows = array();

		foreach ( $map as $role_key => $label ) {
			$role = isset( $wp_roles->roles[ $role_key ] ) ? $wp_roles->roles[ $role_key ] : null;

			if ( ! $role ) {
				continue;
			}

			$rows[] = array(
				'role'        => $role['name'],
				'permissions' => $label,
				'members'     => count( get_users( array( 'role' => $role_key ) ) ),
			);
		}

		return $rows;
	}

	/**
	 * Settings sample values.
	 *
	 * @return array
	 */
	public static function settings() {
		$settings = AMC_DB::get_settings();

		return array(
			'Platform name'   => $settings['platform_name'],
			'Logo'            => $settings['logo'],
			'SEO defaults'    => $settings['seo_defaults'],
			'Social image'    => $settings['social_image'],
			'Homepage chart'  => $settings['homepage_chart'],
			'Methodology text'=> $settings['methodology_text'],
			'Language'        => $settings['language'],
			'Date format'     => $settings['date_format'],
		);
	}

	/**
	 * Logs data.
	 *
	 * @return array
	 */
	public static function logs( $filters = array() ) {
		$rows = AMC_DB::get_ingestion_logs( $filters );

		return array_map(
			function ( $row ) {
				$chart = ! empty( $row['target_chart_id'] ) ? AMC_DB::get_row( 'charts', (int) $row['target_chart_id'] ) : null;
				$context = ! empty( $row['context'] ) ? json_decode( $row['context'], true ) : array();
				$event   = $row['action'] . ': ' . $row['message'];
				if ( is_array( $context ) ) {
					if ( ! empty( $context['job_id'] ) ) {
						$event .= ' (Job #' . (int) $context['job_id'] . ')';
					}
					if ( ! empty( $context['chart_week_id'] ) ) {
						$event .= ' (Week #' . (int) $context['chart_week_id'] . ')';
					}
				}
				return array(
					'id'     => (int) $row['id'],
					'upload_id' => (int) $row['upload_id'],
					'source_row_id' => (int) $row['source_row_id'],
					'time'   => $row['created_at'],
					'event'  => $event,
					'action' => $row['action'],
					'level'  => $row['level'],
					'source' => ! empty( $row['source_platform'] ) ? AMC_Ingestion::platform_label( $row['source_platform'] ) : 'System',
					'country' => ! empty( $row['country'] ) ? $row['country'] : 'Global',
					'chart'  => $chart ? $chart['name'] : 'N/A',
					'upload_status' => ! empty( $row['file_status'] ) ? ucfirst( $row['file_status'] ) : 'N/A',
					'context' => $context,
					'actor'  => 'System',
					'status' => ucfirst( $row['level'] ),
				);
			},
			$rows
		);
	}

	/**
	 * Build logs filters from request.
	 *
	 * @return array
	 */
	public static function logs_filters_from_request() {
		return array(
			'upload_id'       => isset( $_GET['log_upload_id'] ) ? absint( wp_unslash( $_GET['log_upload_id'] ) ) : 0,
			'source_platform' => isset( $_GET['log_source_platform'] ) ? sanitize_key( wp_unslash( $_GET['log_source_platform'] ) ) : '',
			'country'         => isset( $_GET['log_country'] ) ? sanitize_text_field( wp_unslash( $_GET['log_country'] ) ) : '',
			'target_chart_id' => isset( $_GET['log_target_chart_id'] ) ? absint( wp_unslash( $_GET['log_target_chart_id'] ) ) : 0,
			'upload_status'   => isset( $_GET['log_upload_status'] ) ? sanitize_key( wp_unslash( $_GET['log_upload_status'] ) ) : '',
			'level'           => isset( $_GET['log_level'] ) ? sanitize_key( wp_unslash( $_GET['log_level'] ) ) : '',
			'date_from'       => isset( $_GET['log_date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['log_date_from'] ) ) : '',
			'date_to'         => isset( $_GET['log_date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['log_date_to'] ) ) : '',
			'limit'           => 100,
		);
	}

	/**
	 * Summarize invalid rows by reason for an upload.
	 *
	 * @param int $upload_id Upload id.
	 * @return array
	 */
	public static function invalid_row_groups( $upload_id ) {
		$groups = array();

		foreach ( AMC_Ingestion::invalid_rows( $upload_id, 200 ) as $row ) {
			$reason = ! empty( $row['validation_message'] ) ? $row['validation_message'] : 'Unknown validation failure';

			if ( empty( $groups[ $reason ] ) ) {
				$groups[ $reason ] = 0;
			}

			++$groups[ $reason ];
		}

		return $groups;
	}

	/**
	 * Tools data.
	 *
	 * @return array
	 */
	public static function tools() {
		return array(
			array( 'tool' => 'Run diagnostics export', 'description' => 'Export current operational state for logs, review queues, and invalid rows.', 'action' => 'Export diagnostics' ),
			array( 'tool' => 'Flush dashboard routes', 'description' => 'Re-register public and dashboard routes after structural changes.', 'action' => 'Flush routes' ),
			array( 'tool' => 'Export UI snapshot', 'description' => 'Generate a management-state export for review.', 'action' => 'Export snapshot' ),
		);
	}

	/**
	 * Permission presets.
	 *
	 * @return array
	 */
	public static function permissions() {
		return array(
			array( 'role' => 'Administrator', 'dashboard_access' => 'Full', 'publishing' => 'Allowed', 'settings' => 'Allowed' ),
			array( 'role' => 'Editor', 'dashboard_access' => 'Operational dashboard', 'publishing' => 'Allowed', 'settings' => 'Restricted' ),
			array( 'role' => 'Data Manager', 'dashboard_access' => 'Charts, library, weeks', 'publishing' => 'Restricted', 'settings' => 'Restricted' ),
			array( 'role' => 'Viewer', 'dashboard_access' => 'Read only', 'publishing' => 'Blocked', 'settings' => 'Blocked' ),
		);
	}

	/**
	 * Entry rows for a given chart week.
	 *
	 * @param int $week_id Week id.
	 * @return array
	 */
	public static function entries_for_week( $week_id ) {
		$entries = AMC_DB::get_chart_entries( $week_id );

		return array_map(
			function ( $row ) {
				$entity = AMC_Data::get_entity( $row['entity_type'], (int) $row['entity_id'] );

				return array(
					'id'       => (int) $row['id'],
					'rank'     => (int) $row['current_rank'],
					'item'     => $entity ? $entity['name'] : 'Missing item',
					'linked'   => ! empty( $entity['artist']['name'] ) ? $entity['artist']['name'] : ( ! empty( $entity['country'] ) ? $entity['country'] : ucfirst( $row['entity_type'] ) ),
					'previous' => (int) $row['previous_rank'],
					'peak'     => (int) $row['peak_rank'],
					'weeks'    => (int) $row['weeks_on_chart'],
					'movement' => ucwords( str_replace( '-', ' ', $row['movement'] ) ),
					'score'    => (string) $row['score'],
					'score_change' => (string) $row['score_change'],
					'source_count' => (int) $row['source_count'],
					'status'   => $entity ? 'Connected' : 'Missing',
					'entity_type' => $row['entity_type'],
					'entity_id'   => (int) $row['entity_id'],
					'artwork'     => $row['artwork'],
				);
			},
			$entries
		);
	}

	/**
	 * Simple chart id lookup.
	 *
	 * @return array
	 */
	private static function chart_lookup() {
		$rows = AMC_DB::get_rows( 'charts', array( 'order_by' => 'display_order ASC, id ASC' ) );
		$out  = array();

		foreach ( $rows as $row ) {
			$out[ $row['id'] ] = $row;
		}

		return $out;
	}

	/**
	 * Detailed pipeline readiness state for a specific operational cycle.
	 *
	 * @return array
	 */
	public static function pipeline_readiness() {
		$uploads = AMC_DB::get_rows( 'source_uploads', array( 'order_by' => 'id DESC', 'limit' => 5 ) );
		$pending_matches = AMC_DB::count_rows( 'matching_queue', array( 'status' => 'review_needed' ) );
		$running_jobs    = AMC_DB::count_rows( 'jobs', array( 'status' => 'running' ) );
		$queued_jobs     = AMC_DB::count_rows( 'jobs', array( 'status' => 'queued' ) );
		$draft_weeks     = AMC_DB::count_rows( 'chart_weeks', array( 'status' => 'draft' ) );

		$blocked = $pending_matches > 0 || $running_jobs > 0;
		$state   = 'ready';

		if ( $running_jobs > 0 ) {
			$state = 'processing';
		} elseif ( $pending_matches > 0 ) {
			$state = 'blocked';
		} elseif ( $queued_jobs > 0 ) {
			$state = 'queued';
		}

		return array(
			'state'           => $state,
			'blocked'         => $blocked,
			'pending_matches' => (int) $pending_matches,
			'running_jobs'    => (int) $running_jobs,
			'queued_jobs'     => (int) $queued_jobs,
			'draft_weeks'     => (int) $draft_weeks,
			'last_upload'     => ! empty( $uploads[0] ) ? $uploads[0] : null,
		);
	}

	/**
	 * Count label helper.
	 *
	 * @param string $table Table key.
	 * @param string $status Status.
	 * @param string $label Label.
	 * @return string
	 */
	private static function count_label( $table, $status, $label ) {
		return AMC_DB::count_rows( $table, array( 'status' => $status ) ) . ' ' . $label;
	}
}
