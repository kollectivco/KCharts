=== Kontentainment Charts ===
Contributors: kollectivco
Tags: music, charts, artists, tracks, albums
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 4.3.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Premium public-facing music charts experience and control center for WordPress with plugin-based routing, editorial frontend, and plugin-owned admin views.

== Description ==

Kontentainment Charts is a WordPress plugin for chart-led music publishing experiences with public chart pages and an internal admin control center UI.

Features:

* Home page and chart index
* Top Artists, Top Tracks, Top Albums
* Hot 100 Tracks and Hot 100 Artists
* Track and artist detail routes
* GitHub-based update flow for future plugin versions
* Hybrid admin architecture with lightweight wp-admin controls and a full custom dashboard at `/charts-dashboard`

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin through the WordPress plugins screen.
3. Visit Settings > Permalinks once or reactivate the plugin to refresh routes.

== Changelog ==

= 4.3.5 =
* UI/UX monochrome overhaul, improved matching table resolution views, smarter notification memory, and more consistent badge reporting logic safely formatted through the pipeline.
* Cache-busting optimizations for enqueued scripts/styles during development workflows.

= 4.3.4 =
* Performance tweaks and PHP syntactical corrections.


= 4.3.3 =
* Renamed the standalone install identity to use the `kontentainment-charts/` plugin folder, `kontentainment-charts.php` main file, `kontentainment-charts` slug, `kontentainment-charts` text domain, and `kontentainment-charts.zip` package while preserving the Kontentainment Charts brand in the UI.

= 4.3.2 =
* Hardened plugin packaging so the install ZIP is built from an explicit allowlist, verified automatically, and contains only the `kontentainment-charts/` root with `kontentainment-charts.php` as the sole plugin entrypoint.

= 4.3.1 =
* Fixed plugin identity and packaging so the plugin installs as its own standalone package with the `kontentainment-charts` folder, `kontentainment-charts.php` main file, and a packaged ZIP rooted at `kontentainment-charts/`.

= 4.3.0 =
* Added retry/backoff metadata, bulk queue and notification actions, external email/webhook alerts, richer notification linking, and deeper job history analytics for operational monitoring.

= 4.2.0 =
* Added a real jobs and queue view, operator notification center, retry/cancel/rerun controls, queue safety locks, richer observability widgets, and deeper job-linked diagnostics without changing the existing dashboard architecture.

= 4.1.0 =
* Added background-safe job foundations, job states, operator notifications, stronger generation/publish safety checks, and richer operational dashboard visibility for queued, running, failed, and review-heavy workflow states.

= 4.0.1 =
* Refined admin workflow clarity with Bento-style dashboard grouping, clearer matching states, explicit auto-create behavior, and added public discovery pages for artists, tracks, and chart methodology.

= 4.0.0 =
* Added a first-time onboarding flow, production setup checklist, guided first live data workflow, source-specific upload guidance, first publish review summary, and improved zero-data public/admin states without reintroducing any demo content.

= 3.4.1 =
* Removed all automatic demo seeding and mock fallback content, added legacy demo cleanup, and switched the plugin to production-style empty states for fresh installs.

= 3.4.0 =
* Added operational QA tools with filtered ingestion diagnostics, duplicate upload protection, dry-run validation mode, export/debug helpers, and reprocessing plus rollback publishing controls.

= 3.3.0 =
* Added real XLSX/XLS support, stronger parser validation, smarter matching confidence levels, row-level validation feedback, improved dropped-out visibility, and more flexible scoring methodology controls.

= 3.2.0 =
* Added the real Phase 3.2 source-to-chart pipeline with upload metadata, source-specific parsing, weighted generation, trend analysis, draft generation, and publishing status flow.

= 3.1.1 =
* Added a visible plugin-row "Check for updates" link and a forced GitHub refresh action inside wp-admin tools.
* Pushed the real Phase 3.1 backend for source uploads, parsing foundations, matching persistence, scoring rules, and ingestion logs.

= 3.1.0 =
* Added real source uploads, parsing foundations, matching queue persistence, scoring rules persistence, and ingestion logs for the Phase 3.1 backend layer.

= 3.0.0 =
* Added real Phase 3 backend tables, CRUD wiring, publishing/archive state flow, persisted settings, and capability-based access across the admin and public chart data layer.

= 2.1.3 =
* Added a shared dark/light theme system for wp-admin pages and the custom dashboard, with dark mode as the default and persistent theme switching.

= 2.1.2 =
* Improved admin and custom dashboard contrast, surface separation, and readability.

= 2.1.1 =
* Corrected GitHub update versioning for the hybrid dashboard release.

= 2.1.0 =
* Added hybrid admin architecture with lightweight wp-admin controls and a full custom dashboard at `/charts-dashboard`.

= 2.0.0 =
* Added Phase 2 plugin-owned admin dashboard UI.
* Preserved Kontentainment Charts as the visible product brand across the public and admin experience.

= 1.1.0 =
* Editorial frontend polish pass with richer chart summaries, deeper single pages, refined row styling, hover states, and improved mobile behavior.

= 1.0.0 =
* Initial Phase 1 public charts plugin.
