<?php 
$page_title = 'Review & Mapping';
$page_subtitle = 'Resolve unmatched artists and tracks safely.';
include 'partials/header.php'; 
?>

<div class="kc-bento-grid">
    <div class="kc-card" style="grid-column: 1 / -1;">
        <div class="kc-card-header">
            <h3 class="kc-card-title">Pending Resolutions</h3>
        </div>
        <table class="kc-table">
            <thead>
                <tr>
                    <th>Upload #</th>
                    <th>Row Data</th>
                    <th>Extracted Raw Artists</th>
                    <th>Matched Entity</th>
                    <th>Confidence</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="6" style="text-align:center; padding: 40px; color:#888;">No pending reviews. Excellent!</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
