<?php 
$page_title = 'Data Ingestion & Uploads';
$page_subtitle = 'Process new CSV sources against standard parsing profiles.';
include 'partials/header.php'; 
?>

<div class="kc-bento-grid" style="grid-template-columns: 1fr 2fr;">
    <div class="kc-card">
        <div class="kc-card-header">
            <h3 class="kc-card-title">Upload New Source</h3>
        </div>
        <form id="kc-upload-form" method="post" enctype="multipart/form-data">
            
            <div class="kc-form-group">
                <label>Platform Profile</label>
                <select name="parser_key" class="kc-select" required>
                    <option value="">-- Autodetect from Content --</option>
                    <option value="spotify_regional_csv">Spotify Weekly Regional CSV</option>
                    <option value="youtube_topsongs_csv">YouTube Top Songs Weekly CSV</option>
                </select>
            </div>

            <div class="kc-form-group">
                <label>Target Chart Week Date</label>
                <input type="date" name="week_date" class="kc-input" required>
            </div>
            
            <div class="kc-form-group">
                <label>Input Mode</label>
                <select name="input_mode" class="kc-select" required>
                    <option value="source_ranked">Source Ranked (Direct Import)</option>
                    <option value="computed" disabled>Computed (Future V2)</option>
                </select>
            </div>

            <div class="kc-form-group">
                <label>Upload File (CSV only)</label>
                <input type="file" name="chart_file" id="chart_file" accept=".csv" class="kc-input" required>
            </div>

            <div style="margin-top: 16px;">
                <button type="submit" class="kc-btn kc-btn-primary">Preview & Import Data</button>
            </div>
        </form>
    </div>

    <div class="kc-card">
        <div class="kc-card-header">
            <h3 class="kc-card-title">Ingestion History</h3>
        </div>
        <table class="kc-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>File</th>
                    <th>Rows Total</th>
                    <th>Resolved</th>
                    <th>Pending Review</th>
                    <th>Date Uploaded</th>
                </tr>
            </thead>
            <tbody id="kc-ingestion-table">
                <!-- Example Row, we will populate from backend later -->
                <tr>
                    <td colspan="6" style="text-align:center; padding: 40px; color:#888;">Upload your first file to see ingestion history.</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
