<?php 
$page_title = 'Generated Charts';
$page_subtitle = 'Review and publish generated chart weeks.';
include 'partials/header.php'; 
?>

<div class="kc-bento-grid">
    <div class="kc-card" style="grid-column: 1 / -1;">
        <div class="kc-card-header">
            <h3 class="kc-card-title">Chart History</h3>
            <button class="kc-btn kc-btn-primary">Generate New Week</button>
        </div>
        <table class="kc-table">
            <thead>
                <tr>
                    <th>Chart Date</th>
                    <th>Target Chart</th>
                    <th>Status</th>
                    <th>Ranked Entries</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                $prefix = $wpdb->prefix . 'kc_';
                $weeks = $wpdb->get_results("
                    SELECT cw.*, c.name as chart_name
                    FROM {$prefix}chart_weeks cw
                    LEFT JOIN {$prefix}charts c ON cw.chart_id = c.id
                    ORDER BY cw.week_date DESC
                ");
                
                if ( ! empty($weeks) ) :
                    foreach ( $weeks as $week ) :
                        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(id) FROM {$prefix}chart_entries WHERE chart_week_id = %d", $week->id));
                        $status_badge = $week->status === 'published' ? '<span style="color:green; font-weight:bold;">Published</span>' : '<span style="color:orange; font-weight:bold;">Draft</span>';
                ?>
                <tr>
                    <td style="font-weight:700;"><?php echo esc_html($week->week_date); ?></td>
                    <td><?php echo esc_html($week->chart_name ?? 'Global Top 50'); ?></td>
                    <td><?php echo $status_badge; ?></td>
                    <td><?php echo esc_html($count); ?> Entries</td>
                    <td>
                        <?php if ( $week->status !== 'published' ) : ?>
                            <button class="kc-btn kc-publish-btn" data-id="<?php echo esc_attr($week->id); ?>" style="font-size:0.8rem; padding: 4px 10px;">Publish</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; else: ?>
                <tr>
                    <td colspan="5" style="text-align:center; padding: 40px; color:#888;">No generated charts yet. Generate one from the Uploads workflow.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
