<?php 
$page_title = 'System Tools';
$page_subtitle = 'Perform database maintenance and migrations safely.';
include 'partials/header.php'; 
?>

<div class="kc-bento-grid" style="grid-template-columns: 1fr 1fr;">
    <div class="kc-card">
        <div class="kc-card-header">
            <h3 class="kc-card-title">Danger Zone</h3>
        </div>
        <div style="display:flex; flex-direction:column; gap:20px;">
            <div>
                <strong>Re-Run Core DB Migrations</strong>
                <p style="color:#666; font-size:0.85rem;">Force dbDelta to apply table updates directly.</p>
                <button class="kc-btn kc-btn-outline" style="border-color:red; color:red;">Trigger dbDelta</button>
            </div>
            <hr style="border:0; border-top:1px solid #eaeaea; width:100%;">
            <div>
                <strong>Clear ALL Chart Data</strong>
                <p style="color:#666; font-size:0.85rem;">Permanently remove all artists, tracks, and chart history. Useful during staging.</p>
                <button class="kc-btn kc-btn-outline" style="border-color:red; color:red;">Wipe System</button>
            </div>
        </div>
    </div>
    
    <div class="kc-card">
        <div class="kc-card-header">
            <h3 class="kc-card-title">Recalculate Movement</h3>
            <button class="kc-btn kc-btn-outline">Recalculate All</button>
        </div>
        <p style="color:#666; font-size:0.85rem;">
            If you change the history of past weeks, you can manually trigger a full recalculation 
            of the 'Movement' and 'Peak' values for a specific chart.
        </p>
    </div>
</div>

<?php include 'partials/footer.php'; ?>
