document.addEventListener('DOMContentLoaded', () => {

    // Theme logic
    const body = document.body;
    const themeToggle = document.getElementById('kc-theme-toggle');
    const storedTheme = localStorage.getItem('kc-theme');

    if (storedTheme === 'dark') {
        body.classList.add('kc-theme-dark');
    }

    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            if (body.classList.contains('kc-theme-dark')) {
                body.classList.remove('kc-theme-dark');
                localStorage.setItem('kc-theme', 'light');
            } else {
                body.classList.add('kc-theme-dark');
                localStorage.setItem('kc-theme', 'dark');
            }
        });
    }

    // Upload Handler dummy for now
    const uploadForm = document.getElementById('kc-upload-form');
    if (uploadForm) {
        uploadForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = uploadForm.querySelector('button[type="submit"]');
            btn.textContent = "Processing...";
            btn.disabled = true;

            const formData = new FormData(uploadForm);
            formData.append('action', 'kc_upload_chart_data');
            formData.append('nonce', kcObject.nonce);
            
            fetch(kcObject.ajax_url, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                btn.textContent = "Import Complete";
                // Show toast or redirect
                if(data.success) {
                    alert("Import successful! Processed " + data.data.rows + " rows.");
                    window.location.reload();
                } else {
                    alert("Error: " + data.data.message);
                    btn.textContent = "Import Data";
                    btn.disabled = false;
                }
            })
            .catch(err => {
                alert("An error occurred");
                console.error(err);
                btn.textContent = "Import Data";
                btn.disabled = false;
            });
        });
    }

    // Publish Chart Week JS Fix
    document.querySelectorAll('.kc-publish-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = e.target.getAttribute('data-id');
            if ( ! confirm("Publish this chart? It will appear immediately on the frontend public shortcodes.") ) return;

            e.target.textContent = 'Publishing...';
            e.target.disabled = true;

            const formData = new FormData();
            formData.append('action', 'kc_publish_week');
            formData.append('nonce', kcObject.nonce);
            formData.append('week_id', id);

            fetch(kcObject.ajax_url, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    window.location.reload();
                } else {
                    alert("Error: " + data.data.message);
                    e.target.textContent = 'Publish';
                    e.target.disabled = false;
                }
            })
            .catch(err => {
                alert("An error occurred.");
                console.error(err);
                e.target.textContent = 'Publish';
                e.target.disabled = false;
            });
        });
    });
});
