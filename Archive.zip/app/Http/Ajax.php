<?php
namespace Kontentainment\Charts\Http;

use Kontentainment\Charts\Core\Container;
use Kontentainment\Charts\Services\UploadService;

class Ajax {
    
    protected $container;

    public function __construct( Container $container ) {
        $this->container = $container;
    }

    public function init() {
        add_action( 'wp_ajax_kc_upload_chart_data', [ $this, 'handle_upload' ] );
        add_action( 'wp_ajax_kc_publish_week', [ $this, 'handle_publish' ] );
    }

    public function handle_upload() {
        check_ajax_referer( 'kc_ajax_nonce', 'nonce' );

        if ( ! current_user_can( 'upload_kc_chart_data' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized capability.' ] );
        }

        if ( empty( $_FILES['chart_file']['tmp_name'] ) ) {
            wp_send_json_error( [ 'message' => 'No file provided.' ] );
        }

        $parser_key = sanitize_text_field( $_POST['parser_key'] ?? '' );
        $week_date = sanitize_text_field( $_POST['week_date'] ?? '' );
        $input_mode = sanitize_text_field( $_POST['input_mode'] ?? 'source_ranked' );

        try {
            $service = $this->container->get( UploadService::class );
            $result = $service->process_upload( $_FILES['chart_file'], $parser_key, $week_date, $input_mode );
            wp_send_json_success( $result );
        } catch ( \Exception $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ] );
        }
    }

    public function handle_publish() {
        check_ajax_referer( 'kc_ajax_nonce', 'nonce' );

        if ( ! current_user_can( 'publish_kc_chart_weeks' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized capability.' ] );
        }

        $week_id = isset($_POST['week_id']) ? intval($_POST['week_id']) : 0;
        if ( ! $week_id ) {
            wp_send_json_error( [ 'message' => 'Invalid week ID.' ] );
        }

        try {
            $builder = $this->container->get( \Kontentainment\Charts\Services\ChartBuilder::class );
            $builder->publish_week( $week_id );
            wp_send_json_success( [ 'message' => 'Chart published successfully.' ] );
        } catch ( \Exception $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ] );
        }
    }
}
