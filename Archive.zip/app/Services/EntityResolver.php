<?php
namespace Kontentainment\Charts\Services;

use Kontentainment\Charts\Core\Container;

class EntityResolver {

    protected $container;
    
    public function __construct( Container $container ) {
        $this->container = $container;
    }

    public function resolve( $normalized, $upload_id, $source_row_id, $chart_id, $country_id, $platform_slug, $week_date ) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'kc_';
        
        $raw_artist_names = $normalized['raw_artist_names'];
        $raw_track_title = $normalized['raw_track_name'];
        
        $new_artists = 0;
        $new_tracks = 0;

        // 1. Resolve Artists (split by comma or common delimiters)
        $artist_parts = preg_split('/(,|&|feat\.|ft\.)/i', $raw_artist_names);
        $artist_ids = [];
        $primary_artist_id = null;
        
        foreach ( $artist_parts as $idx => $raw_name ) {
            $name = trim($raw_name);
            if ( empty($name) ) continue;
            
            $norm_name = sanitize_title($name);
            if ( empty($norm_name) ) continue;

            // Search DB by normalized name
            $artist_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}artists WHERE normalized_name = %s LIMIT 1", $norm_name));
            
            if ( !$artist_id ) {
                // Auto-create artist
                $wpdb->insert( "{$prefix}artists", [
                    'name' => $name,
                    'normalized_name' => $norm_name,
                    'slug' => $norm_name . '-' . uniqid(),
                    'status' => 'active'
                ]);
                $artist_id = $wpdb->insert_id;
                $new_artists++;
            }
            
            $artist_ids[] = [
                'id' => $artist_id,
                'role' => $idx === 0 ? 'main' : 'featured'
            ];
            
            if ( $idx === 0 ) {
                $primary_artist_id = $artist_id;
            }
        }
        
        // 2. Resolve Track
        $track_status = 'auto_matched';
        $track_norm = sanitize_title($raw_track_title);
        $track_id = null;
        
        if ( !empty($track_norm) && $primary_artist_id ) {
            $track_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$prefix}tracks WHERE normalized_title = %s AND primary_artist_id = %d LIMIT 1",
                $track_norm, $primary_artist_id
            ));
            
            if ( !$track_id ) {
                $wpdb->insert( "{$prefix}tracks", [
                    'title' => $raw_track_title,
                    'normalized_title' => $track_norm,
                    'slug' => $track_norm . '-' . uniqid(),
                    'primary_artist_id' => $primary_artist_id,
                    'status' => 'active'
                ]);
                $track_id = $wpdb->insert_id;
                $new_tracks++;
                $track_status = 'auto_created';
                
                // insert to bridge table for all authors
                foreach ( $artist_ids as $k => $art ) {
                    $wpdb->insert( "{$prefix}track_artists", [
                        'track_id' => $track_id,
                        'artist_id' => $art['id'],
                        'role' => $art['role'],
                        'sort_order' => $k
                    ]);
                }
            }
            
            // 3. Save weekly metric safely
            $wpdb->replace( "{$prefix}track_week_metrics", [
                'track_id' => $track_id,
                'chart_id' => $chart_id,
                'country_id' => $country_id,
                'platform_slug' => $platform_slug,
                'week_date' => $week_date,
                'source_rank' => $normalized['raw_rank'],
                'source_previous_rank' => $normalized['raw_previous_rank'],
                'source_peak_rank' => $normalized['raw_peak_rank'] ?? null,
                'source_weeks_on_chart' => $normalized['raw_weeks_on_chart'] ?? null,
                'metric_primary_type' => $normalized['metric_primary_type'],
                'metric_primary_value' => $normalized['metric_primary_value'],
                'growth_percent' => $normalized['raw_growth_value'],
                'external_url' => $normalized['external_url'],
                'external_uri' => $normalized['external_uri'],
                'upload_id' => $upload_id,
                'source_row_id' => $source_row_id
            ]);
            
        } else {
            $track_status = 'needs_review';
        }
        
        return [
            'status' => $track_status,
            'track_id' => $track_id,
            'new_artists' => $new_artists,
            'new_tracks' => $new_tracks
        ];
    }
}
